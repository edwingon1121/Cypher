//  Edwin Gonzalez
//  ITP 165, Spring 2016
//  Lab Practical 6
//  edwingon@usc.edu
//
//  lp06.cpp
//  lp06
//
//  Created by Edwin Gonzalez on 2/2/16.
//  Copyright © 2016 Edwin Gonzalez. All rights reserved.
//

#include <iostream>
#include <string>

int main()
{
    std::string word="word";
    std::string cipher="EHTGDBWIUQRXLMVFSJCPYZKAON";
    
    bool done=true;
    
    while (done)
    {

    std::cout<< "Enter a word to encrypt: ";
    std::cin>>word;
    
    for (int i=0; i<word.length();i++)
    {
        if (word[i] >= 'A' && word[i] <= 'Z')//uppercase
            {
                int index=0;
                 index=word[i]-'A';
                word[i]= cipher[index];
                
            }
        
        
        if (word[i] >= 'a' && word[i] <= 'z')// lowercase
        {
            int index=word[i]-'a';
            word[i]= cipher[index];
            //word[i]=word[i]-('A'-'a'); //changes the letter to lowercase
        }
    }
    
        std::cout<<"Your word encrypts to: "<<word<<std::endl;

    char tryagain='n';
    std::cout<<"Would you like to go again (Y/N)? ";
    std::cin>>tryagain;
        
     if (tryagain=='n'||tryagain=='N')
     {
      done=false;
     }
        
    }
    
    return 0;
}
